// let inputs = document.querySelectorAll('input');
// let button = document.querySelector('button');
// let span = document.querySelector('span');

// button.onclick = function() {
//     let result = Number(inputs[0].value) + Number(inputs[1].value);
//     span.innerHTML = result;
// }

// function fn(x, y) {
//     return x + y;
// }

// fn('a', true);