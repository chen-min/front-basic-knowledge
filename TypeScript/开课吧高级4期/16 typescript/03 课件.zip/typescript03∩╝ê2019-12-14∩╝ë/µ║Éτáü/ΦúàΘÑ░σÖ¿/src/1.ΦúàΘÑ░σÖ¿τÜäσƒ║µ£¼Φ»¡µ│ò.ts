/**
 * ts 中的装饰器语法功能只能对类进行
 * 还需要注意以下：
 *  - 开启 experimentalDecorators 编译选项
 *  - 不同的装饰器函数会有一定的格式标准，并不是随便一个普通函数就可以作为装饰器
 * 
 * 装饰器函数是在类解析创建的过程中被执行的，不是类实例化的时候
 */
// import * as fs from 'fs';

function log(target: any, name: string, descriptor: PropertyDescriptor) {
    /**
     * PropertyDescriptor:
     *  Object.defineProperty(obj, 'x', {
     *      // 这个对象就是描述符
     *  })
     */
    // console.log('我是一个装饰器');

    // 其实就是原来的函数进行扩展

    // console.log(descriptor.value);

    // 先保存一份原始的函数
    let fn = descriptor.value;

    // 修改原始函数
    descriptor.value = function(a: number, b: number) {
        console.log('参数', a, b);
        let rs = fn(a, b);
        console.log('结果', rs);
        return rs;
    }

}

function storage(target: any, name: string, descriptor: PropertyDescriptor) {
    let fn = descriptor.value;

    descriptor.value = function(a: number, b: number) {
        let rs = fn(a, b);
        // localStorage.setItem('v', rs);
        console.log('这是模拟的存储', rs);
        return rs;
    }
}

class M {

    @log @storage
    static add(a: number, b: number) {
        return a + b;
    }

    // @log
    static sub(a: number, b: number) {
        return a - b;
    }

    name() {
        
    }

}

let v1 = M.add(1, 2);
console.log(v1);