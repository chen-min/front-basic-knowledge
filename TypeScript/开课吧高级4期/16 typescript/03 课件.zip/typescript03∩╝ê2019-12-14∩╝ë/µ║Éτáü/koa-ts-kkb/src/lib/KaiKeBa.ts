/**
 * 1. 根据传入的 dir 去加载这个文件夹里面的所有 ts 文件
 * 2. 根据 Controller，Get，装饰器，把类和类中的方法提取出来，注册到路由对象中
 * 3. 把路由对象注册到 app 中
 */

import * as Koa from 'koa';
import * as glob from 'glob';
import * as KoaRouter from 'koa-router'
import 'reflect-metadata';

interface IOptions {
    app: Koa,
    dir: string
}

export {Controller, Get} from './Decorators';

export default class KaiKeBa {

    router = new KoaRouter();

    constructor(
        public options: IOptions
    ) {
        this.loaderControllers();
    }

    loaderControllers() {
        // this.options.dir 读取所有的 ts 文件
        let files = glob.sync( this.options.dir );
        // console.log(files);
        files.forEach(file => {
            let conctrollerClass = require(file).default;
            
            console.log( Reflect.getMetadata('isController', conctrollerClass) );

            // 去分析加载进来的所有文件已经对应的类

            // let controller = new conctrollerClass();

            // console.log(conctrollerClass.default);
            // console.log(Reflect.getMetadata('route', conctrollerClass));

            // this.router.get('/', controller.main);
        });
    }

}