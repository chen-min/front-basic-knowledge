import 'reflect-metadata';

export function Get(path: string) {
    return function(target: any, name: string, descriptor: PropertyDescriptor) {

        // 给当前的这个类的这个方法加上一些标记，然后在路由处理的通过这个标记识别当前是否要添加到路由
        // console.log(target, name, descriptor);
        Reflect.defineMetadata('isController', true, target);
        

    }
}

export function Controller(path: string) {
    return function(target: any) {
        console.log('target', target);

        // Reflect.defineMetadata('isController', true, target);
    }
}