import * as Koa from 'koa';
import KaiKeBa from './lib/KaiKeBa';

(async function() {
    const app = new Koa();

    new KaiKeBa({
        app,
        dir: __dirname + '/controllers/**/*.ts'
    })

    
})();