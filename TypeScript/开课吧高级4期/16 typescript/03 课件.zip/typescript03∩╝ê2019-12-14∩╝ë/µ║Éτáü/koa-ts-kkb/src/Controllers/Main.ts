import {Controller, Get} from '../lib/KaiKeBa';

@Controller('')
export default class MainController {

    @Get('/')
    async main() {
        // ctx.body = 'Hello';
    }


    async list(ctx) {
        ctx.body = 'Hello';
    }

}