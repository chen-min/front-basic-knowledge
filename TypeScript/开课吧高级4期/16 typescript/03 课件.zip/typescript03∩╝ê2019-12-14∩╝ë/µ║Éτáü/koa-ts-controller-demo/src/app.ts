import * as Koa from 'koa';
import {bootstrapControllers} from 'koa-ts-controllers';

(async function() {
    const app = new Koa();

    bootstrapControllers(app, {
        basePath: '/api',
        controllers: [__dirname + '/controllers/**/*.ts'],
        initBodyParser: true,
        boomifyErrors: true,
        versions: {
            1: true
        }
    });
    
    app.listen(7070, function() {
        console.log('ok');
    });
})();