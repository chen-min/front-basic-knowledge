import {Controller, Get, Ctx} from 'koa-ts-controllers';
import { Context } from 'koa';


@Controller('')
export class MainController {

    @Get('/')
    main(
        @Ctx() ctx: Context
    ) {
        return 'Hello';
    }

    @Get('/list')
    list(
        @Ctx() ctx: Context
    ) {
        return 'List...!!!!';
    }

}